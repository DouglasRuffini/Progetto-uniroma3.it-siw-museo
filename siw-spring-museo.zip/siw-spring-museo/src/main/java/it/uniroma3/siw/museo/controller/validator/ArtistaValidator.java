package it.uniroma3.siw.museo.controller.validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import it.uniroma3.siw.museo.model.Artista;
import it.uniroma3.siw.museo.service.ArtistaService;

/**Classe ArtistaValidator
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see ArtistaValidator
 * 
 */

@Component
public class ArtistaValidator implements Validator  {
	@Autowired
	private ArtistaService artistaService;
	
		
    private static final Logger logger = LoggerFactory.getLogger(ArtistaValidator.class);

	@Override
	public void validate(Object o, Errors errors) {
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nome", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cognome", "required");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dataDiNascita", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "luogoDiNascita", "required");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nazionalita", "required");
//		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dataDiMorte", "required");
		
//		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "luogoDiMorte", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "biografia", "required");
		
       
         Artista  a =(Artista)o;
        
		if (!errors.hasErrors()) {
			logger.debug("confermato: valori non nulli");
			if (this.artistaService.alreadyExists(Long.valueOf(a.getId()))) {
				logger.debug("e' un duplicato");
				errors.reject("duplicato");
			}
		}
	}

	@Override
	public boolean supports(Class<?> aClass) {
		return Artista.class.equals(aClass);
	}
	
	/**Valida l'eventualità che il tasto invio venga
	 * premuto senza aver inserito nulla nel form
	 * 
	 * @param o
	 * @return
	 */
	public boolean validation(Object o) {
	    Artista  a =(Artista)o;
	    
	    if((a.getNome()==null)||(a.getNome().isBlank()))
    		return false;  
	    
    	if((a.getCognome()==null)||(a.getCognome().isBlank()))
    		return false;
    	
//    	if((a.getDataDiNascita()==null)||(String.valueOf(a.getDataDiNascita()).isBlank()))
//    		return false;
//    	else

   	
    	if((a.getLuogoDiNascita()==null)||(a.getLuogoDiNascita().isBlank()))
    		return false;
    	
    	if((a.getNazionalita()==null)||(a.getNazionalita().isBlank()))
    		return false;
    	
    	if((a.getBiografia()==null)||(a.getBiografia().isBlank()))
    		return false;
    	
		return true;
	}
	
	/**Valida l'eventualità che il tasto invio sia
	 * usato per modificare i dati gia presenti
	 * 
	 * @param o
	 * @return
	 */
	public boolean validaModifica(Object o) {
		Artista  a =(Artista)o;
		if (this.artistaService.alreadyExists(Long.valueOf(a.getId())))
			return true;
		return false;
	}
	
}
