package it.uniroma3.siw.museo.repository;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.museo.model.Curatore;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface CuratoreRepository extends CrudRepository<Curatore, Long> {

	List<Curatore> findByNomeAndCognome(String nome, String cognome);

	List<Curatore> findByNomeOrCognome(String nome, String cognome);
	
	/*Attenzione!! i campi nel caso no Transactional sono quelli dichiarati nella
	 * classe altrimenti vanno indicati come trascritti nel database*/
	@Modifying(clearAutomatically = true)
    @Query("update Curatore a set a.nome = :nome, "
    		+ "a.cognome = :cognome, a.dataDiNascita = :dataDiNascita, a.luogoDiNascita = :luogoDiNascita"
    		+ ", a.matricola = :matricola, a.telefono = :telefono, a.email = :email  where a.id = :id") 
    public void update(@Param("id") Long id, @Param("nome") String nome, @Param("cognome") String cognome, 
    		@Param("dataDiNascita") String dataDiNascita, @Param("luogoDiNascita") String luogoDiNascita, @Param("matricola") String matricola, 
    		@Param("telefono") String telefono, @Param("email") String email);
	
	@Modifying(clearAutomatically = true)
	@Query(value="select id, nome, cognome, data_di_nascita, luogo_di_nascita, matricola, telefono, email, curatori_museo_id from Curatore where matricola = :matricola and id <> :id", nativeQuery = true)
	@Transactional
	public List<Curatore> existMatricola(@Param("matricola") String matricola, @Param("id") Long id);	
	
	@Modifying(clearAutomatically = true)
	@Query(value="select id, nome, cognome, data_di_nascita, luogo_di_nascita, matricola, telefono, email from Curatore order by RANDOM() LIMIT 1", nativeQuery = true)
	@Transactional
	public List<Curatore> curatoreRandom();
	
	@Modifying(clearAutomatically = true)
	@Query(value="select cognome, data_di_nascita, luogo_di_nascita, matricola, telefono, email, curatori_museo_id  from Curatore join Collezione on Curatore.id = Collezione.curatore_museo_id  where curatore_museo_id = :id", nativeQuery = true)
	@Transactional
	public List<Curatore> curatorePerCollezione(@Param("id") Long id);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Collezione set curatore_museo_id = null where curatore_museo_id = :id") 
	@Transactional
	public void dissociaCollezioni(@Param("id") Long id); 
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Curatore set curatori_museo_id = null where id = :id") 
	@Transactional
	public void dissociaMuseo(@Param("id") Long id); 
}
