package it.uniroma3.siw.museo.repository;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import it.uniroma3.siw.museo.model.Museo;

public interface MuseoRepository extends CrudRepository<Museo, Long> {
	public List<Museo> findByNome(String nome);
	
	@Modifying(clearAutomatically = true)
    @Query("update Museo a set a.nome = :nome, "
    		+ "a.indirizzo = :indirizzo, a.telefono = :telefono, a.email = :email, a.nazionalita = :nazionalita, a.pathopere = :pathopere   where a.id = :id") 
    public void update(@Param("id") Long id, @Param("nome") String nome, @Param("indirizzo") String indirizzo, 
    		@Param("telefono") String telefono, @Param("email") String email, @Param("nazionalita") String nazionalita, @Param("pathopere") String pathopere);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Curatore set curatori_museo_id = null where curatori_museo_id = :id") 
	@Transactional
	public void dissociaCuratori(@Param("id") Long id);
	

	
	
	
}
