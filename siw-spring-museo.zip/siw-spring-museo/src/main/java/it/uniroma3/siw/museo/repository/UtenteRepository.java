package it.uniroma3.siw.museo.repository;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import it.uniroma3.siw.museo.model.Utente;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface UtenteRepository  extends CrudRepository<Utente, Long> {
	
	@Modifying(clearAutomatically = true)
	@Query(value="select Utente.id, nome, cognome from Utente join Credentials on Utente.id = Credentials.riconoscimento_utente_id where Credentials.ruolo in ('ADMIN', 'DEFAULT','') ", nativeQuery = true)
	@Transactional
	public List<Utente> ritornaUtenzaRuoliEsclusoSuper();
	
	@Modifying(clearAutomatically = true)
    @Query(value = "insert into Utente ( id, nome, cognome ) values (:1, :'super', :'super') ", nativeQuery = true) 
	@Transactional
	public void  inserisciUtenteIniziale();
	

}