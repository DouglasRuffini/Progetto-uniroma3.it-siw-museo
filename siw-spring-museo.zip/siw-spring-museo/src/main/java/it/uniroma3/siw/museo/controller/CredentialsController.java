package it.uniroma3.siw.museo.controller;
import org.springframework.stereotype.Controller;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Controller
public class CredentialsController {

}
