package it.uniroma3.siw.museo.controller.validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import it.uniroma3.siw.museo.model.Credentials;
import it.uniroma3.siw.museo.model.Utente;
import it.uniroma3.siw.museo.service.CredentialsService;
import static it.uniroma3.siw.museo.model.Credentials.SUPERVISOR_ROLE;
import static it.uniroma3.siw.museo.model.Credentials.ADMIN_ROLE;
import static it.uniroma3.siw.museo.model.Credentials.DEFAULT_ROLE;
/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class CredentialsValidator implements Validator {
	
	
	@Autowired
	    private CredentialsService credentialsService;

	    final Integer MAX_USERNAME_LENGTH = 20;
	    final Integer MIN_USERNAME_LENGTH = 4;
	    final Integer MAX_PASSWORD_LENGTH = 20;
	    final Integer MIN_PASSWORD_LENGTH = 6;

	    /**Richiama i valori che compariranno nei campi del form
	     * 
	     */
	    @Override
	    public void validate(Object o, Errors errors) {
	        Credentials credentials = (Credentials) o;
	        String username = credentials.getUsername().trim();
	        String password = credentials.getPassword().trim();
	        
	        if (username.isEmpty())
	            errors.rejectValue("username", "required");
	        else if (username.length() < MIN_USERNAME_LENGTH || username.length() > MAX_USERNAME_LENGTH)
	            errors.rejectValue("username", "size");
	        else if (this.credentialsService.getCredentials(username) != null)
	            errors.rejectValue("username", "duplicate");

	        if (password.isEmpty())
	            errors.rejectValue("password", "required");
	        else if (password.length() < MIN_PASSWORD_LENGTH || password.length() > MAX_PASSWORD_LENGTH)
	            errors.rejectValue("password", "size");
	    }
	    
	    public boolean validateMessageUsername(Object o) {
	        Credentials credentials = (Credentials) o;
	        String username = credentials.getUsername().trim();
	        
	        if (username.isEmpty())
	            return false;
	        if (username.length() < MIN_USERNAME_LENGTH || username.length() > MAX_USERNAME_LENGTH)
	        	return false;
	        if (this.credentialsService.getCredentials(username) != null)
	        	return false;

	        return true;
	    }
	    
	    public boolean validateMessagePassword(Object o) {
	        Credentials credentials = (Credentials) o;
	        String password = credentials.getPassword().trim();	        
	        
	        if (password.isEmpty())
	        	 return false;
	        if (password.length() < MIN_PASSWORD_LENGTH || password.length() > MAX_PASSWORD_LENGTH)
	        	 return false;
	        
	        
	        return true;
	    }
	    
	    public boolean validateMessageRuolo(Object o) {
	        Credentials credentials = (Credentials) o;
	        String ruolo = credentials.getRole().trim();	        
	        
	        if (ruolo.isEmpty())
	        	 return false;
	        if (!ruolo.equals(SUPERVISOR_ROLE)|| !ruolo.equals(ADMIN_ROLE)|| !ruolo.equals(DEFAULT_ROLE))
	        	 return false;
	        	        
	        return true;
	    }
	    
	    public boolean validateMessageUsernameModifica(String username) {
	       	        
	        if (username == null )
	            return false;
	        if (username.length() < MIN_USERNAME_LENGTH || username.length() > MAX_USERNAME_LENGTH)
	        	return false;
	        if (this.credentialsService.getCredentials(username) != null)
	        	return false;

	        return true;
	    }
	    
	    public boolean validateMessagePasswordModifica(String password) {        
	        
	        if (password == null )
	        	 return false;
	       
	        return true;
	    }
	    
	    public boolean validateMessageRuoloModifica(String ruolo ) {	      
	        if (ruolo == null )
	        	 return false;
	        if (!ruolo.equals(SUPERVISOR_ROLE)|| !ruolo.equals(ADMIN_ROLE)|| !ruolo.equals(DEFAULT_ROLE))
	        	 return false;
	        	        
	        return true;
	    }

	    @Override
	    public boolean supports(Class<?> clazz) {
	        return Utente.class.equals(clazz);
	    }

}
