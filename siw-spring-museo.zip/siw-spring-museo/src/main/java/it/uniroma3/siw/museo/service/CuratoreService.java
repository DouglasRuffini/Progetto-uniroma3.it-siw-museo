package it.uniroma3.siw.museo.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.museo.model.Curatore;
import it.uniroma3.siw.museo.repository.CuratoreRepository;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class CuratoreService {
	@Autowired
	private CuratoreRepository curatoreRepository; 
	
	@Transactional
	public Curatore inserisci(Curatore curatore) {
		return (Curatore) curatoreRepository.save(curatore);
	}
	
	@Transactional
	public void dissociaCollezioni(Long id) {
		curatoreRepository.dissociaCollezioni(id);
	}
	
	@Transactional
	public void dissociaMuseo(Long id) {
		curatoreRepository.dissociaMuseo(id);
	}
	
	@Transactional
	public void aggiorna(Curatore curatore) {
		curatoreRepository.update(curatore.getId(), curatore.getNome(), curatore.getCognome(), curatore.getDataDiNascita(), 
				curatore.getLuogoDiNascita(), curatore.getMatricola(), curatore.getTelefono(), curatore.getEmail());
	}
	
	@Transactional
	public void eliminaCuratore(Curatore curatore) {
		curatoreRepository.delete(curatore);
	}
	
	@Transactional
	public void eliminaCuratoreId(Long id) {
		curatoreRepository.deleteById(id);
	}
	
	@Transactional
	public List<Curatore>  curatoreRandom() {
		return (List<Curatore>) curatoreRepository.curatoreRandom();
	}
	
	@Transactional
	public List<Curatore>  curatorePerCollezione(Long id) {
		return (List<Curatore>) curatoreRepository.curatorePerCollezione(id);
	}
	
	@Transactional
	public List<Curatore> curatorePerNomeAndCognome(String nome, String cognome) {
		return curatoreRepository.findByNomeAndCognome(nome, cognome);
	}

	@Transactional
	public List<Curatore> tuttiICuratori() {
		return (List<Curatore>) curatoreRepository.findAll();
	}

	@Transactional
	public Curatore curatorePerId(Long id) {
		Optional<Curatore> curatore =curatoreRepository.findById(id);

		if (curatore.isPresent())
			return curatore.get();
		else 
			return null;
	}

	@Transactional
	public boolean alreadyExistsCuratoreNomeAndCognome(Curatore curatore) {
		List<Curatore> curatori = this.curatoreRepository.findByNomeAndCognome(curatore.getNome(), curatore.getCognome());
		if (curatori.size() > 0)
			return true;
		else 
			return false;
	}
	
	@Transactional
	public boolean alreadyExistsCuratoreNomeOrCognome(Curatore curatore) {
		List<Curatore> curatori = this.curatoreRepository.findByNomeOrCognome(curatore.getNome(), curatore.getCognome());
		if (curatori.size() > 0)
			return true;
		else 
			return false;
	}

	@Transactional
	public boolean alreadyExists(Long id) {
		return this.curatoreRepository.existsById(id);
	}
	
	@Transactional
	public boolean matricolaAllreadyExists(Curatore c) {
		if(c.getMatricola()!=null) {
			for (Curatore curatori : this.curatoreRepository.existMatricola(c.getMatricola(), c.getId())) {
				if(curatori!=null) {
					if (curatori.getMatricola()!=null)
						return false;
					else 
						return true;
				}	
				else 
					return true;
			}
			return true;
		}
		return false;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
