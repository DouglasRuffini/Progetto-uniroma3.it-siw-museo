package it.uniroma3.siw.museo.repository;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.museo.model.Artista;
import it.uniroma3.siw.museo.model.Opera;


/**Classe ArtistaRepository
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see ArtistaRepository
 * 
 * @param <Artista>
 * @param <Long>
 */

public interface ArtistaRepository  extends CrudRepository<Artista,Long>{
	
	public List<Artista> findByNome(String nome);

	public List<Artista> findByNomeAndCognome(String nome, String cognome);

	public List<Artista> findByNomeOrCognome(String nome, String cognome);
	
	@Modifying(clearAutomatically = true)
    @Query("update Artista a set a.cognome =:cognome, "
    		+ "a.nome = :nome, a.luogoDiNascita = :luogoDiNascita, "
    		+ "a.dataDiNascita = :dataDiNascita, a.nazionalita = :nazionalita, "
    		+ "a.luogoDiMorte = :luogoDiMorte, a.biografia = :biografia, a.dataDiMorte = :dataDiMorte where a.id = :id") 
    public void update(@Param("id") Long id, @Param("cognome") String cognome, @Param("nome") String nome, 
    		@Param("luogoDiNascita") String luogoDiNascita, @Param("dataDiNascita") String dataDiNascita, @Param("nazionalita") String nazionalita, 
    		@Param("luogoDiMorte") String luogoDiMorte, @Param("biografia") String biografia, @Param("dataDiMorte") String dataDiMorte); 
	
	/*Attenzione!! i campi Transactional sono quelli del db */
	@Modifying(clearAutomatically = true)
    @Query(value = "select id, cognome, nome, data_di_nascita, luogo_di_nascita, nazionalita, luogo_di_morte, biografia, data_di_morte  from Artista ORDER BY RANDOM()  LIMIT 1", nativeQuery = true) 
	@Transactional
	public List<Artista>  unArtistaRandom();
	
	@Modifying(clearAutomatically = true)
    @Query(value = "select id, titolo, anno_realizzazione, descrizione, collezione_opere_id, opera_artista_id, path from Opera where opera_artista_id = :opera_artista_id  LIMIT 1", nativeQuery = true) 
	@Transactional
	public List<Opera>  unOperaPerArtistaRandom(@Param("opera_artista_id") Long opera_artista_id);
	
}


