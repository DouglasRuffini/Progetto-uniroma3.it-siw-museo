package it.uniroma3.siw.museo.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.museo.model.Collezione;
import it.uniroma3.siw.museo.repository.CollezioneRepository;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class CollezioneService {
	@Autowired
	private CollezioneRepository collezioneRepository;
	
	@Transactional
	public Collezione inserisci(Collezione collezione) {
		return (Collezione) collezioneRepository.save(collezione);
	}
	
	@Transactional
	public void aggiorna(Collezione collezione) {
		collezioneRepository.update(collezione.getId(), collezione.getDescrizione(), collezione.getNome(), collezione.getDatacreazione());
	}
	
	@Transactional
	public void eliminaCollezione(Collezione collezione) {
		collezioneRepository.delete(collezione);
	}
	
	@Transactional
	public void dissociaCuratore(Long id) {
		collezioneRepository.dissociaCuratore(id);
	}
	
	@Transactional
	public List<Collezione>  collezioneRandom() {
		return (List<Collezione>)  collezioneRepository.collezioniRandom();
	}
	
	@Transactional
	public void eliminaCollezioneId(Long id) {
		collezioneRepository.deleteById(id);
	}
	
	@Transactional
	public void aggiornaCollezione(Long id, Long curatore_id) {
		collezioneRepository.updateCollezione(id, curatore_id);;
	}
	
	@Transactional
	public List<Collezione> collezionePerNome(String nome) {
		return collezioneRepository.findByNome(nome);
	}

	@Transactional
	public List<Collezione> tutteLeCollezioni() {
		return (List<Collezione>) collezioneRepository.findAll();
	}
	
	@Transactional
	public List<Collezione> selezionaCollezioniNonAssociateCuratore() {
		return (List<Collezione>) collezioneRepository.collezioniNonAssociate();
	}
	
	@Transactional
	public List<Collezione> selezionaCollezioniAssociateCuratore(Long id) {
		return (List<Collezione>) collezioneRepository.collezioniAssociateCuratore(id);
	}

	@Transactional
	public Collezione collezionePerId(Long id) {
		Optional<Collezione> collezione =collezioneRepository.findById(id);

		if (collezione.isPresent())
			return collezione.get();
		else 
			return null;
	}

	@Transactional
	public boolean alreadyExistsCollezioneNome(Collezione collezione) {
		List<Collezione> coll = this.collezioneRepository.findByNome(collezione.getNome());
		if (coll.size() > 0)
			return true;
		else 
			return false;
	}
	
	@Transactional
	public boolean alreadyExists(Long id) {
		return this.collezioneRepository.existsById(id);
	}

}
