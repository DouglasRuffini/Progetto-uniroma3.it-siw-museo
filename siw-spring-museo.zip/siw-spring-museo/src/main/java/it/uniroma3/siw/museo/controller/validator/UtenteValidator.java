package it.uniroma3.siw.museo.controller.validator;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import it.uniroma3.siw.museo.model.Utente;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class UtenteValidator implements Validator {

	final Integer MAX_NAME_LENGTH = 100;
    final Integer MIN_NAME_LENGTH = 2;

    @Override
    public void validate(Object o, Errors errors) {
        Utente utente = (Utente) o;
        String nome = utente.getNome().trim();
        String cognome = utente.getCognome().trim();
       
        if (nome.isEmpty())
            errors.rejectValue("nome", "required");
        else if (nome.length() < MIN_NAME_LENGTH || nome.length() > MAX_NAME_LENGTH)
            errors.rejectValue("nome", "size");

        if (cognome.isEmpty())
            errors.rejectValue("cognome", "required");
        else if (cognome.length() < MIN_NAME_LENGTH || cognome.length() > MAX_NAME_LENGTH)
            errors.rejectValue("cognome", "size");
        
    }

    public boolean validateNome(Object o) {
        Utente utente = (Utente) o;
        String nome = utente.getNome().trim();         
       
        if (nome.isEmpty())
           return false;
        if (nome.length() < MIN_NAME_LENGTH || nome.length() > MAX_NAME_LENGTH)
           return false;
        return true;
        
    }
    
    public boolean validateCognome(Object o) {
        Utente utente = (Utente) o;
        String cognome = utente.getCognome().trim();

        if (cognome.isEmpty())
            return false;
        if (cognome.length() < MIN_NAME_LENGTH || cognome.length() > MAX_NAME_LENGTH)
            return false;
        return true;
        
    }

    
    @Override
    public boolean supports(Class<?> clazz) {
        return Utente.class.equals(clazz);
    }


}
