package it.uniroma3.siw.museo.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.museo.model.Artista;
import it.uniroma3.siw.museo.model.Opera;
import it.uniroma3.siw.museo.repository.ArtistaRepository;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class ArtistaService {
	@Autowired
	private ArtistaRepository artistaRepository; 
	
	@Transactional
	public Artista inserisci(Artista artista) {
		return (Artista) artistaRepository.save(artista);
	}
	
	@Transactional     
    public void aggiorna(Artista artista) {
		artistaRepository.update(artista.getId(), artista.getCognome(), artista.getNome(), 
				artista.getLuogoDiNascita(), artista.getDataDiNascita(), artista.getNazionalita(), 
				artista.getLuogoDiMorte(), artista.getBiografia(), artista.getDataDiMorte());
	}
	
	
	@Transactional
	public void eliminaArtista(Artista artista) {
		artistaRepository.delete(artista);
	}
	
	@Transactional
	public void eliminaArtistaId(Long id) {
		artistaRepository.deleteById(id);
	}
	
	@Transactional
	public List<Artista> artistiPerNomeAndCognome(String nome, String cognome) {
		return artistaRepository.findByNomeAndCognome(nome, cognome);
	}

	@Transactional
	public List<Artista> tuttiGliArtisti() {
		return (List<Artista>) artistaRepository.findAll();
	}
	
	@Transactional
	public List<Artista> artistaRandom() {
		return (List<Artista>) artistaRepository.unArtistaRandom();
	}
	
	@Transactional
	public List<Opera> operaRandomPerArtistaRandom(Long id) {
		return (List<Opera>) artistaRepository.unOperaPerArtistaRandom(id);
	}

	@Transactional
	public Artista artistiPerId(Long id) {
		Optional<Artista> artista =artistaRepository.findById(id);

		if (artista.isPresent())
			return artista.get();
		else 
			return null;
	}

	@Transactional
	public boolean alreadyExistsArtistaNomeAndCognome(Artista artista) {
		List<Artista> artisti = this.artistaRepository.findByNomeAndCognome(artista.getNome(), artista.getCognome());
		if (artisti.size() > 0)
			return true;
		else 
			return false;
	}
	
	@Transactional
	public boolean alreadyExistsArtistaNomeOrCognome(Artista artista) {
		List<Artista> artisti = this.artistaRepository.findByNomeOrCognome(artista.getNome(), artista.getCognome());
		if (artisti.size() > 0)
			return true;
		else 
			return false;
	}

	@Transactional
	public boolean alreadyExists(Long id) {
		return this.artistaRepository.existsById(id);
	}
}
