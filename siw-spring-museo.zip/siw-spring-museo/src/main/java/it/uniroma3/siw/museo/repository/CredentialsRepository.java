package it.uniroma3.siw.museo.repository;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import javax.transaction.Transactional;
import it.uniroma3.siw.museo.model.Credentials;


/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface CredentialsRepository extends CrudRepository<Credentials, Long> {
	public Optional<Credentials> findByUsername(String username);
	
	@Modifying(clearAutomatically = true)
	@Query(value="select id, username, password, ruolo, riconoscimento_utente_id from Credentials where riconoscimento_utente_id = :idUtente", nativeQuery=true)
	@Transactional
	public List<Credentials> ritornaCredenzialiUtente(@Param("idUtente") Long id);
	
	@Modifying(clearAutomatically = true)
    @Query(value="update Credentials set  ruolo = :ruolo where  riconoscimento_utente_id = :idUtente", nativeQuery=true)
	@Transactional
	public void updateRuolo(@Param("idUtente") Long id, @Param("ruolo") String ruolo);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "insert into Credentials ( id, username, password, ruolo, riconoscimento_utente_id from ) values (:1, :'super', :'$2a$10$ZzietxZWbpcRnnTNvip9YOiWkDUvJ25Pu/lnktTU1q5WPGUCsUuZK', :'SUPER', :1) ", nativeQuery = true) 
	@Transactional
	public void  inserisciCredentialsIniziale();
	
	@Modifying(clearAutomatically = true)
	@Query(value="select Credentials.id, username, password, ruolo, riconoscimento_utente_id from Utente join Credentials on Utente.id = Credentials.riconoscimento_utente_id where Credentials.ruolo ='SUPER'and Credentials.riconoscimento_utente_id = 1 and Utente.id = 1 and password = '$2a$10$ZzietxZWbpcRnnTNvip9YOiWkDUvJ25Pu/lnktTU1q5WPGUCsUuZK') ", nativeQuery = true)
	@Transactional
	public List<Credentials> ritornaUtenzaIstallazione();

}
