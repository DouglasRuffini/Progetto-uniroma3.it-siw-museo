package it.uniroma3.siw.museo.model;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**Classe Museo
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see Museo
 *
 */

@Entity
public class Museo {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(nullable = false)
	private String nome;
	private String indirizzo;
	private String telefono;
	private String email;
	private String nazionalita;
	private String pathopere;
	
	@OneToMany(mappedBy ="curatoriMuseo", cascade = {CascadeType.ALL} )
	private List<Curatore> curatoriDelMuseo= new ArrayList<>();//collezione riferita alla classe "Many"
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNazionalita() {
		return nazionalita;
	}

	public void setNazionalita(String nazionalita) {
		this.nazionalita = nazionalita;
	}

	public String getPathopere() {
		return pathopere;
	}

	public void setPathopere(String pathopere) {
		this.pathopere = pathopere;
	}

	public List<Curatore> getCuratoriDelMuseo() {
		return curatoriDelMuseo;
	}

	public void setCuratoriDelMuseo(List<Curatore> curatoriDelMuseo) {
		this.curatoriDelMuseo = curatoriDelMuseo;
	}

}
