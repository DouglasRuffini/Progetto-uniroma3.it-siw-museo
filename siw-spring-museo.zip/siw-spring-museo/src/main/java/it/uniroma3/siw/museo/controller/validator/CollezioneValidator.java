package it.uniroma3.siw.museo.controller.validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import it.uniroma3.siw.museo.model.Collezione;
import it.uniroma3.siw.museo.service.CollezioneService;
import it.uniroma3.siw.museo.service.CuratoreService;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class CollezioneValidator implements Validator {
	@Autowired
	private CollezioneService collezioneService;
	
	@Autowired
	private CuratoreService curatoreService;
	
    private static final Logger logger = LoggerFactory.getLogger(CollezioneValidator.class);
	
	@Override
	public boolean supports(Class<?> aClass) {
		return  Collezione.class.equals(aClass);
	}

	
	@Override
	public void validate(Object o, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nome", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "descrizione", "required");
//		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "datacreazione", "required");
		
		Collezione  c =(Collezione)o;
		if (!errors.hasErrors()) {
			logger.debug("confermato: valori non nulli");
			if (this.collezioneService.alreadyExists(Long.valueOf(c.getId()))) {
				logger.debug("e' un duplicato");
				errors.reject("duplicato");
			}
		}
	}

	public boolean validation(Object o) {
		Collezione  c =(Collezione)o;
	    
	    if((c.getNome()==null)||(c.getNome().isBlank()))
    		return false;    	    	
//    	if((c.getDatacreazione()==null)||(c.getDatacreazione().isBlank()))
//    		return false;
    	if((c.getDescrizione()==null)||(c.getDescrizione().isBlank()))
    		return false;
		return true;
	}
	
	/**Valida l'eventualità che il tasto invio sia
	 * usato per modificare i dati gia presenti
	 * 
	 * @param o
	 * @return
	 */
	public boolean validaModifica(Object o) {
		Collezione  c =(Collezione)o;
		if (this.collezioneService.alreadyExists(Long.valueOf(c.getId())))
			return true;
		return false;
	}
	
	public boolean validaCuratore(Long id) {
		if (this.curatoreService.alreadyExists(Long.valueOf(id)))
			return true;
		return false;
	}
}
