package it.uniroma3.siw.museo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import it.uniroma3.siw.museo.service.MuseoService;

/**Classe 
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * 
 */

@Controller
public class MuseoController {
	
	@Autowired
	private MuseoService museoService;
	
	@RequestMapping(value = "/informazioni", method = RequestMethod.GET)
    public String getInformazione(Model model) {
		/*l'attributo di model restituirà la tranzazione sql di museo al Service */
    	model.addAttribute("museo", this.museoService.tuttiIMuseo());
    	return "informazioni.html";
    }
}
