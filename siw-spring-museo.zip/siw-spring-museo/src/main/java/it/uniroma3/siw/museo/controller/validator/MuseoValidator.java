package it.uniroma3.siw.museo.controller.validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import it.uniroma3.siw.museo.model.Museo;
import it.uniroma3.siw.museo.service.MuseoService;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class MuseoValidator implements Validator {

	@Autowired
	private MuseoService museoService;
	
		
    private static final Logger logger = LoggerFactory.getLogger(ArtistaValidator.class);
	
    
    @Override
	public boolean supports(Class<?> aClass) {
		return Museo.class.equals(aClass);
	}

	@Override
	public void validate(Object o, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nome", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "indirizzo", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "telefono", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nazionalita", "required");
//		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "pathopere", "required");
		Museo  museo =(Museo)o;
		if (!errors.hasErrors()) {
			logger.debug("confermato: valori non nulli");
			if (this.museoService.alreadyExists(Long.valueOf(museo.getId()))) {
				logger.debug("e' un duplicato");
				errors.reject("duplicato");
			}
		}
	}
	
	public boolean validation(Object o) {
		Museo  museo =(Museo)o;
		if((museo.getNome()==null)||(museo.getNome().isBlank()))
    		return false;    	    	
    	if((museo.getIndirizzo()==null)||(museo.getIndirizzo().isBlank()))
    		return false;
    	if((museo.getTelefono()==null)||(museo.getTelefono().isBlank()))
    		return false;
    	if((museo.getEmail()==null)||(museo.getEmail().isBlank()))
    		return false;
    	if((museo.getNazionalita()==null)||(museo.getNazionalita().isBlank()))
    		return false;
//     	if((museo.getPathopere()==null)||(museo.getPathopere().isBlank()))
//     		return false;
		return true;
	}
	
	/**Valida l'eventualità che il tasto invio sia
	 * usato per modificare i dati gia presenti
	 * 
	 * @param o
	 * @return
	 */
	public boolean validaModifica(Object o) {
		Museo  museo =(Museo)o;
		if (this.museoService.alreadyExists(Long.valueOf(museo.getId())))
			return true;
		return false;
	}

}
