package it.uniroma3.siw.museo.model;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


/**Classe Artista
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see Artista
 */

@Entity
public class Artista {
		
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(nullable = false)
	private String nome;
	private String cognome;
	private String luogoDiNascita;
	private String nazionalita;
	
	@Column(nullable = false)
	private String dataDiNascita;
	
	@Column(nullable = true)	
	private String luogoDiMorte;
	@Column(nullable = true, length = 100000)
	private String biografia;
	@Column(nullable = true)
	private String dataDiMorte;
		
	
	@OneToMany(mappedBy = "operaArtista", cascade = {CascadeType.ALL})
	private List<Opera> opere = new ArrayList<>();//collezione riferita alla classe "Many"
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getDataDiNascita() {
		return dataDiNascita;
	}

	public void setDataDiNascita(String dataDiNascita) {
		this.dataDiNascita = dataDiNascita;
	}

	public String getLuogoDiNascita() {
		return luogoDiNascita;
	}

	public void setLuogoDiNascita(String luogoDiNascita) {
		this.luogoDiNascita = luogoDiNascita;
	}

	public String getNazionalita() {
		return nazionalita;
	}

	public void setNazionalita(String nazionalita) {
		this.nazionalita = nazionalita;
	}

	public String getDataDiMorte() {
		return dataDiMorte;
	}

	public void setDataDiMorte(String dataDiMorte) {
		this.dataDiMorte = dataDiMorte;
	}

	public String getLuogoDiMorte() {
		return luogoDiMorte;
	}

	public void setLuogoDiMorte(String luogoDiMorte) {
		this.luogoDiMorte = luogoDiMorte;
	}
	
	public String getBiografia() {
		return biografia;
	}

	public void setBiografia(String biografia) {
		this.biografia = biografia;
	}
	
}
