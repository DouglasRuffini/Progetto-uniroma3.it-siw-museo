package it.uniroma3.siw.museo.controller.validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import it.uniroma3.siw.museo.model.Opera;
import it.uniroma3.siw.museo.service.ArtistaService;
import it.uniroma3.siw.museo.service.CollezioneService;
import it.uniroma3.siw.museo.service.OperaService;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class OperaValidator implements Validator {
	@Autowired
	private OperaService operaService;
	
	@Autowired
	private ArtistaService artistaService;
	
	@Autowired
	private CollezioneService collezioneService;
	
    private static final Logger logger = LoggerFactory.getLogger(ArtistaValidator.class);
	@Override
	public boolean supports(Class<?> aClass) {
		return Opera.class.equals(aClass);
	}

	@Override
	public void validate(Object o, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "titolo", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "annoRealizzazione", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "descrizione", "required");
        Opera  opera =(Opera)o;
		if (!errors.hasErrors()) {
			logger.debug("confermato: valori non nulli");
			if (this.operaService.alreadyExists(Long.valueOf(opera.getId()))) {
				logger.debug("e' un duplicato");
				errors.reject("duplicato");
			}
		}
	}
	
	public boolean validation(Object o) {
		Opera  opera =(Opera)o;
	    
	    if((opera.getTitolo()==null)||(opera.getTitolo().isBlank()))
    		return false;    	    	
    	if( (String.valueOf(opera.getAnnoRealizzazione())== null)||(String.valueOf(opera.getAnnoRealizzazione()).isBlank()))
    		return false;
    	if((opera.getDescrizione()==null)||(opera.getDescrizione().isBlank()))
    		return false;
		return true;
	}
	
	/**Valida l'eventualità che il tasto invio sia
	 * usato per modificare i dati gia presenti
	 * 
	 * @param o
	 * @return
	 */
	public boolean validaModifica(Object o) {
		Opera  opera =(Opera)o;
		if (this.operaService.alreadyExists(Long.valueOf(opera.getId())))
			return true;
		return false;
	}
	
	public boolean validaArtista(Long id) {
		if (this.artistaService.alreadyExists(Long.valueOf(id)))
			return true;
		return false;
	}
	
	public boolean validaCollezione(Long id) {
		if (this.collezioneService.alreadyExists(Long.valueOf(id)))
			return true;
		return false;
	}
	
}
