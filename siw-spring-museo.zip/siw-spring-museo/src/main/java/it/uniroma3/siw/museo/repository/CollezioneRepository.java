package it.uniroma3.siw.museo.repository;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.museo.model.Collezione;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface CollezioneRepository extends CrudRepository<Collezione, Long> {
	
	public List<Collezione> findByNome(String nome);
	
	@Modifying(clearAutomatically = true)
    @Query("update Collezione a set a.descrizione = :descrizione, "
    		+ "a.nome = :nome, a.datacreazione = :datacreazione where a.id = :id") 
    public void update(@Param("id") Long id, @Param("descrizione") String descrizione, @Param("nome") String nome, 
    		@Param("datacreazione") String datacreazione); 
		
	@Modifying(clearAutomatically = true)
    @Query(value = "select id, nome, descrizione, datacreazione, curatore_museo_id from Collezione where curatore_museo_id is null ", nativeQuery = true) 
	@Transactional
	public List<Collezione>  collezioniNonAssociate();
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Collezione set curatore_museo_id = :curatore_museo_id where id = :id") 
	@Transactional
    public void updateCollezione(@Param("id") Long id, @Param("curatore_museo_id") Long curatore_museo_id);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Collezione set curatore_museo_id = null where id = :id") 
	@Transactional
    public void dissociaCuratore(@Param("id") Long id);
	
	@Modifying(clearAutomatically = true)
    @Query(value = "select id, nome, descrizione, datacreazione, curatore_museo_id from Collezione order by RANDOM() LIMIT 1 ", nativeQuery = true) 
	@Transactional
	public List<Collezione>  collezioniRandom();
	
	@Modifying(clearAutomatically = true)
    @Query(value = "select id, nome as nome, descrizione, datacreazione, curatore_museo_id from Collezione where curatore_museo_id = :id ", nativeQuery = true) 
	@Transactional
	public List<Collezione>  collezioniAssociateCuratore(@Param("id") Long id);
	
}
