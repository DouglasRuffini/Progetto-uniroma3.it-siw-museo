package it.uniroma3.siw.museo.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.museo.model.Credentials;
import it.uniroma3.siw.museo.repository.CredentialsRepository;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class CredentialsService {

	@Autowired
	protected PasswordEncoder passwordEncoder;

	@Autowired
	protected CredentialsRepository credentialsRepository;

	@Transactional
	public Credentials getCredentials(Long id) {
		Optional<Credentials> result = this.credentialsRepository.findById(id);
		return result.orElse(null);
	}
	
	@Transactional
	public Credentials getCredentials(String username) {
		Optional<Credentials> result = this.credentialsRepository.findByUsername(username);
		return result.orElse(null);
	}

	@Transactional
	public Credentials saveCredentials(Credentials credentials) {
		credentials.setRole(Credentials.DEFAULT_ROLE);
		credentials.setPassword(this.passwordEncoder.encode(credentials.getPassword()));
		return this.credentialsRepository.save(credentials);
	}
	
	@Transactional
	public Long ritornaCredenzialiUtente(Long id) {
		List<Credentials> list = new ArrayList<Credentials>();
		list = this.credentialsRepository.ritornaCredenzialiUtente(id);
		for(Credentials c : list)
			if(c!=null && c.getId()>0)
				return Long.valueOf(c.getId());
		 
		return Long.valueOf(null);
	}
	
	@Transactional
	public void aggiornaRuoloUtente(Long id, String ruolo) {
		this.credentialsRepository.updateRuolo(id, ruolo);		
	}
	
	@Transactional
	public void inserisciCredenzialiIniziali() {
		this.credentialsRepository.inserisciCredentialsIniziale();
	}
	
	@Transactional
	public Long ritornaCredenzialiIstallazione() {
		List<Credentials> list = new ArrayList<Credentials>();
		list = this.credentialsRepository.ritornaUtenzaIstallazione();
		for(Credentials c : list)
			if(c!=null && c.getId()>0)
				return Long.valueOf(c.getId());
		 
		return Long.valueOf(null);
	}

}
