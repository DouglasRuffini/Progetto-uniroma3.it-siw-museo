package it.uniroma3.siw.museo.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.museo.model.Museo;
import it.uniroma3.siw.museo.repository.MuseoRepository;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class MuseoService {
	@Autowired
	private MuseoRepository museoRepository;
	
	@Transactional
	public Museo inserisci(Museo museo) {
		return (Museo) museoRepository.save(museo);
	}
	
	@Transactional
	public void aggiorna(Museo museo) {
		museoRepository.update(museo.getId(), museo.getNome(), museo.getIndirizzo(), museo.getTelefono(), museo.getEmail(), museo.getNazionalita(), museo.getPathopere());
	}
	
	@Transactional
	public void eliminaMuseo(Museo museo) {
		museoRepository.delete(museo);
	}
	
	@Transactional
	public void eliminaMuseoId(Long id) {
		museoRepository.deleteById(id);
	}
	
	
	@Transactional
	public void dissociaCuratori(Long id) {
		museoRepository.dissociaCuratori(id);
	}
	
	@Transactional
	public List<Museo> museoPerNome(String nome) {
		return museoRepository.findByNome(nome);
	}

	@Transactional
	public List<Museo> tuttiIMuseo() {
		return (List<Museo>) museoRepository.findAll();
	}

	@Transactional
	public Museo museoPerId(Long id) {
		Optional<Museo> museo =museoRepository.findById(id);

		if (museo.isPresent())
			return museo.get();
		else 
			return null;
	}

	@Transactional
	public boolean alreadyExistsMuseoNome(Museo museo) {
		List<Museo> coll = this.museoRepository.findByNome(museo.getNome());
		if (coll.size() > 0)
			return true;
		else 
			return false;
	}
	
	@Transactional
	public boolean alreadyExists(Long id) {
		return this.museoRepository.existsById(id);
	}
	
	@Transactional
	public boolean alreadyNotExists() {
		if(this.tuttiIMuseo().isEmpty())
			return true;
		return false;
	}
}
