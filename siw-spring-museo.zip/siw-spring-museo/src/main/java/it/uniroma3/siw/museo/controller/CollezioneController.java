package it.uniroma3.siw.museo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import it.uniroma3.siw.museo.model.Collezione;
import it.uniroma3.siw.museo.service.CollezioneService;
import it.uniroma3.siw.museo.service.OperaService;

/**Classe CollezioneController
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @ CollezioneController
 * 
 */

@Controller
public class CollezioneController {
	@Autowired
	private CollezioneService collezioniService;
	
	@Autowired
	private OperaService operaService;

	
	@RequestMapping(value = "/collezioni", method = RequestMethod.GET)
    public String getCollezioni(Model model) {
		
		for(Collezione c : this.collezioniService.collezioneRandom()) {
			model.addAttribute("collezioni", c);
			model.addAttribute("opere", operaService.operePerCollezione(c.getId()));
		}
    	
    	return "collezioni.html";
    }
	
}
