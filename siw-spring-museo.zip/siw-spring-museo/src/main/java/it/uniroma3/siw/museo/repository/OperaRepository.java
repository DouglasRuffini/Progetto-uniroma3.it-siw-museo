package it.uniroma3.siw.museo.repository;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import it.uniroma3.siw.museo.model.Opera;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

public interface OperaRepository extends CrudRepository<Opera, Long> {
	public List<Opera> findByTitolo(String titolo);
	
	@Modifying(clearAutomatically = true)
    @Query("update Opera a set a.titolo = :titolo, "
    		+ "a.annoRealizzazione = :annoRealizzazione, a.descrizione = :descrizione, a.foto = :foto, a.path = :path  where a.id = :id") 
    public void update(@Param("id") Long id, @Param("titolo") String titolo, @Param("annoRealizzazione") int annoRealizzazione, 
    		@Param("descrizione") String descrizione, @Param("foto") byte[] foto, @Param("path") String path); 
	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Opera set opera_artista_id = :opera_artista_id where id = :id") 
	@Transactional
    public void updateArtista(@Param("id") Long id, @Param("opera_artista_id") Long opera_artista_id); 
	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Opera set collezione_opere_id = :collezione_opere_id where id = :id") 
	@Transactional
    public void updateCollezione(@Param("id") Long id, @Param("collezione_opere_id") Long opera_artista_id);
	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "insert into Opera ( id, titolo, anno_realizzazione, descrizione, opera_artista_id, foto, path) values (:id, :titolo, :annoRealizzazione, :descrizione, :opera_artista_id, :foto, :path) ", nativeQuery = true) 
	@Transactional
	public void insertInto(@Param("id") Long id, @Param("titolo") String titolo, @Param("annoRealizzazione") int annoRealizzazione, 
    		@Param("descrizione") String descrizione,  @Param("opera_artista_id") Long opera_artista_id, @Param("foto") byte[] foto, @Param("path") String path); 
	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "select id, titolo, anno_realizzazione, descrizione, collezione_opere_id, opera_artista_id, foto, path from Opera where opera_artista_id is null ", nativeQuery = true) 
	@Transactional
	public List<Opera>  opereNonAssociate();
	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Opera set opera_artista_id = null where id = :id") 
	@Transactional
    public void dissociaArtista(@Param("id") Long id); 
	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Opera set opera_artista_id = null where opera_artista_id = :id") 
	@Transactional
    public void dissociaOpere(@Param("id") Long id); 
	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "select id, titolo, anno_realizzazione, descrizione, collezione_opere_id, opera_artista_id, foto, path from Opera where collezione_opere_id is null ", nativeQuery = true) 
	@Transactional
	public List<Opera>  collezioniNonAssociate();
	
	
	
//	@Modifying(clearAutomatically = true)
//    @Query(value = "update Opera set path = :path where id = :id") 
//	@Transactional
//    public void updatePath(@Param("id") Long id, @Param("path") String path); 
//	
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "select id, titolo, anno_realizzazione, descrizione, collezione_opere_id, opera_artista_id, foto, path from Opera ORDER BY RANDOM()  LIMIT 1", nativeQuery = true) 
	@Transactional
	public List<Opera>  unOperaRandom();
		
	
	
	/*le query native devono appartenere al repository dell'entità, non possono essere dichiarate in altri repositoryl */
	@Modifying(clearAutomatically = true)
    @Query(value = "select id, titolo, anno_realizzazione, descrizione, collezione_opere_id, opera_artista_id, foto, path from Opera where opera_artista_id = :opera_artista_id ", nativeQuery = true) 
	@Transactional
	public List<Opera>  operePerArtista(@Param("opera_artista_id") Long opera_artista_id);
		
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "select id, titolo, anno_realizzazione, descrizione, collezione_opere_id, opera_artista_id, foto, path from Opera where collezione_opere_id = :collezione_opere_id ", nativeQuery = true) 
	@Transactional
	public List<Opera>  operePerCollezione(@Param("collezione_opere_id") Long collezione_opere_id);
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "update Opera set foto = :foto_opera where id = :id") 
	@Transactional
    public void updateFoto(@Param("id") Long id, @Param("foto_opera") byte[] foto_opera); 
	
	
	@Modifying(clearAutomatically = true)
    @Query(value = "select foto from Opera where id = :id") 
	@Transactional
    public List<Opera>  selezionaFoto(@Param("id") Long id);
}










