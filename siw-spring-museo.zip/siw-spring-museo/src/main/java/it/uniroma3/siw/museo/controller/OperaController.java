package it.uniroma3.siw.museo.controller;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Base64Utils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import it.uniroma3.siw.museo.model.Opera;
import it.uniroma3.siw.museo.service.OperaService;

/**Classe OperaController
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see OperaController
 */

@Controller
public class OperaController {
	@Autowired
	private OperaService opereService;
	
	private  byte[] ritornaImmagine(Long id) {
		Opera o = this.opereService.operaPerId(id);
		byte[] b = (byte[]) ArrayUtils.toPrimitive(o.getFoto());
		return b;

	}
	@RequestMapping(value = "/opere", method = RequestMethod.GET)
    public String getOpera(Model model) {
		model.addAttribute("opere",  this.opereService.opereRandom() );
		for(Opera o : this.opereService.opereRandom() ) {
			if(o.getFoto()!=null)
				model.addAttribute("image", Base64Utils.encodeToString(this.ritornaImmagine(o.getId())));
			else
				model.addAttribute("image", null);
    	}
    	return "opere.html";
    }
	
//	@RequestMapping(value = "/opera/{id}", method = RequestMethod.GET)
//	public String getOpera(@PathVariable("id") Long id, Model model) {
//		model.addAttribute("artista", this.opereService.operaPerId(id));
//		return "artista.html";
//	}
	
	
}
