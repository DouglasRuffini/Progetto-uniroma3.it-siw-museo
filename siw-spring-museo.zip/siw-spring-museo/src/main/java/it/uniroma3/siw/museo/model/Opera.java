package it.uniroma3.siw.museo.model;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**Classe Opera
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see Opera
 */

@Entity
public class Opera {
		
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(nullable = false)
	private String titolo;
	private int annoRealizzazione;
	private String descrizione;
	@Column(nullable = true)
	private byte[] foto;
	
	@Column(nullable = true)
	private String path;

	@ManyToOne(cascade = {CascadeType.ALL})
	private Collezione collezioneOpere;//nome del mappedBy della classe "One"
	
	@ManyToOne(cascade = {CascadeType.ALL})
	private Artista operaArtista;//nome del mappedBy della classe "One"
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public int getAnnoRealizzazione() {
		return annoRealizzazione;
	}

	public void setAnnoRealizzazione(int annoRealizzazione) {
		this.annoRealizzazione = annoRealizzazione;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public Collezione getCollezioneOpere() {
		return collezioneOpere;
	}

	public void setCollezioneOpere(Collezione collezioneOpere) {
		this.collezioneOpere = collezioneOpere;
	}
	
	public Artista getOperaArtista() {
		return this.operaArtista;
	}
	
	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
	public byte[] getFoto() {
		return foto;
	}

	public void setFoto(byte[] foto) {
		this.foto = foto;
	}
}
