package it.uniroma3.siw.museo.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.museo.model.Utente;
import it.uniroma3.siw.museo.repository.UtenteRepository;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class UtenteService {
	@Autowired
	private UtenteRepository utenteRepository; 

	/**
	 * This method retrieves a User from the DB based on its ID.
	 * @param id the id of the User to retrieve from the DB
	 * @return the retrieved User, or null if no User with the passed ID could be found in the DB
	 */
	@Transactional
	public Utente getUser(Long id) {
		Optional<Utente> result = this.utenteRepository.findById(id);
		return result.orElse(null);
	}

	/**
	 * This method saves a User in the DB.
	 * @param user the User to save into the DB
	 * @return the saved User
	 * @throws DataIntegrityViolationException if a User with the same username
	 *                              as the passed User already exists in the DB
	 */
	@Transactional
	public Utente saveUser(Utente utente) {
		return this.utenteRepository.save(utente);
	}

	/**
	 * This method retrieves all Users from the DB.
	 * @return a List with all the retrieved Users
	 */
	@Transactional
	public List<Utente> getAllUsers() {
		List<Utente> result = new ArrayList<>();
		Iterable<Utente> iterable = this.utenteRepository.findAll();
		for(Utente utente : iterable)
			result.add(utente);
		return result;
	}
	
	public List<Utente> tuttiGliUtenti(){
		return (List<Utente>) this.utenteRepository.findAll();
	}
	
	public List<Utente> ritornaUtenzaRuoliEsclusoSuper(){
		return (List<Utente>) this.utenteRepository.ritornaUtenzaRuoliEsclusoSuper();		
	}
	
	@Transactional
	public void inserisciUtenteIniziale() {
		utenteRepository.inserisciUtenteIniziale();
	}

}
