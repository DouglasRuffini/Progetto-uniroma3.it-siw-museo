package it.uniroma3.siw.museo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import it.uniroma3.siw.museo.service.ArtistaService;

/**Classe ArtistaController
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 * @see ArtistaController
 * 
 */

@Controller
public class ArtistaController {

	@Autowired
	private ArtistaService artistaService;

	
	/**Associazione tra pattern artisti e metodo get
	 * che ritorna tutti gli artisti presenti nel museo.
	 * 
	 * @param model
	 * @return lista artisti
	 */
	@RequestMapping(value = "/artisti", method = RequestMethod.GET)
	public String getArtista(Model model) {
		
		model.addAttribute("artisti",this.artistaService.artistaRandom());
				
		return "artisti.html";
	}

}
