package it.uniroma3.siw.museo.service;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import it.uniroma3.siw.museo.model.Opera;
import it.uniroma3.siw.museo.repository.OperaRepository;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Service
public class OperaService {
	@Autowired
	private OperaRepository operaRepository; 
	
	@Transactional
	public Opera inserisci(Opera opera) {
		return (Opera) operaRepository.save(opera);
	}
	
	@Transactional
	public void eliminaOpera(Opera opera) {
		operaRepository.delete(opera);
	}
	
	@Transactional
	public void aggiorna(Opera opera) {
		operaRepository.update(opera.getId(), opera.getTitolo(), opera.getAnnoRealizzazione(), opera.getDescrizione(), opera.getFoto(), opera.getPath());
	}
	
	@Transactional
	public void associaArtista(Opera opera, Long id) {
		operaRepository.insertInto(opera.getId(), opera.getTitolo(), opera.getAnnoRealizzazione(), opera.getDescrizione(), id, opera.getFoto(), opera.getPath());
	}
	
	@Transactional
	public void aggiornaArtista(Long id_opera, Long id_artista) {
		operaRepository.updateArtista(id_opera, id_artista);
	}
	
	@Transactional
	public void updateFotoOpera(Long id, byte[] foto_opera) {
		operaRepository.updateFoto(id, foto_opera);
	}
	
	@Transactional
	public void aggiornaCollezione(Long id_opera, Long id_collezione) {
		operaRepository.updateCollezione(id_opera, id_collezione);
	}
	
//	@Transactional
//	public void updatePath(Long id_opera, String path) {
//		operaRepository.updatePath(id_opera, path);
//	}
	
	@Transactional
	public void dissociaArtista(Long id_opera) {
		operaRepository.dissociaArtista(id_opera);
	}
	
	@Transactional
	public void dissociaOpere(Long id_artista) {
		operaRepository.dissociaOpere(id_artista);
	}
	
	@Transactional
	public List<Opera> selezionaOpereNonAssociate() {
		return (List<Opera>) operaRepository.opereNonAssociate();
	}
	
	@Transactional
	public List<Opera> selezionaFotoOpere(Long id) {
		return (List<Opera>) operaRepository.selezionaFoto(id);
	}
	
	@Transactional
	public List<Opera> opereRandom() {
		return (List<Opera>) operaRepository.unOperaRandom();
	}
	
	@Transactional
	public List<Opera> operePerArtista(Long id) {
		return (List<Opera>) operaRepository.operePerArtista(id);
	}
	
	@Transactional
	public List<Opera> operePerCollezione(Long id) {
			return (List<Opera>) operaRepository.operePerCollezione(id);
	}
	
	@Transactional
	public List<Opera> selezionaOpereCollezioniNonAssociate() {
		return (List<Opera>) operaRepository.collezioniNonAssociate();
	}
	
	@Transactional
	public void eliminaOperaId(Long id) {
		operaRepository.deleteById(id);
	}
	
	@Transactional
	public List<Opera> operaPerTitolo(String titolo) {
		return operaRepository.findByTitolo(titolo);
	}

	@Transactional
	public List<Opera> tutteLeOpere() {
		return (List<Opera>) operaRepository.findAll();
	}

	@Transactional
	public Opera operaPerId(Long id) {
		Optional<Opera> opera =operaRepository.findById(id);

		if (opera.isPresent())
			return opera.get();
		else 
			return null;
	}

	@Transactional
	public boolean alreadyExistsOperaTitolo(Opera opera) {
		List<Opera> opera_list = this.operaRepository.findByTitolo(opera.getTitolo());
		if (opera_list.size() > 0)
			return true;
		else 
			
			return false;
	}

	@Transactional
	public boolean alreadyExists(Long id) {
		return this.operaRepository.existsById(id);
	}

	
}

