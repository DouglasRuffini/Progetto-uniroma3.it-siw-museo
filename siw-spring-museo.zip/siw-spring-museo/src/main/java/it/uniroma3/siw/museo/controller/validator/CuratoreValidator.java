package it.uniroma3.siw.museo.controller.validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import it.uniroma3.siw.museo.model.Curatore;
import it.uniroma3.siw.museo.service.CuratoreService;

/**
 * 
 * @author DOUGLAS RUFFINI (Mat.:482379 - UniRomaTre Dipartimento di Ingegneria Informatica.)
 *
 */

@Component
public class CuratoreValidator implements Validator {


	@Autowired
	private CuratoreService curatoreService;
	
		
    private static final Logger logger = LoggerFactory.getLogger(ArtistaValidator.class);
	
    
    @Override
	public boolean supports(Class<?> aClass) {
		return Curatore.class.equals(aClass);
	}

	@Override
	public void validate(Object o, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nome", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cognome", "required");
//		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dataDiNascita", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "luogoDiNascita", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "matricola", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "telefono", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "required");
		Curatore  curatore =(Curatore)o;
		if (!errors.hasErrors()) {
			logger.debug("confermato: valori non nulli");
			if (this.curatoreService.alreadyExists(Long.valueOf(curatore.getId()))) {
				logger.debug("e' un duplicato");
				errors.reject("duplicato");
			}
		}
	}

	public boolean validation(Object o) {
		Curatore  curatore =(Curatore)o;
	    
	    if((curatore.getNome()==null)||(curatore.getNome().isBlank()))
    		return false;    	    	
    	if((curatore.getCognome()==null)||(curatore.getCognome().isBlank()))
    		return false;
    	if((curatore.getDataDiNascita()==null)||(curatore.getDataDiNascita().isBlank()))
    		return false;
    	if((curatore.getLuogoDiNascita()==null)||(curatore.getLuogoDiNascita().isBlank()))
    		return false;
    	if((curatore.getMatricola()==null)||(curatore.getMatricola().isBlank()))
    		return false;
    	if((curatore.getTelefono()==null)||(curatore.getTelefono().isBlank()))
    		return false;
    	if((curatore.getEmail()==null)||(curatore.getEmail().isBlank()))
    		return false;
		return true;
	}
	
	/**Valida l'eventualità che il tasto invio sia
	 * usato per modificare i dati gia presenti
	 * 
	 * @param o
	 * @return
	 */
	public boolean validaModifica(Object o) {
		Curatore  curatore =(Curatore)o;
		if (this.curatoreService.alreadyExists(Long.valueOf(curatore.getId())))
			return true;
		return false;
	}
	
	
	public boolean validaMatricola(Object o) {
		Curatore  curatore =(Curatore)o;
		if (this.curatoreService.matricolaAllreadyExists((curatore)))
			return true;
		return false;
	}
	
	
	
	
	
	
	
	
	
	
	
}
