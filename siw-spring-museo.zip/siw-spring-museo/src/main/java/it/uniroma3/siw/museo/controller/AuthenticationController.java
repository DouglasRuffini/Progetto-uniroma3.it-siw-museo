package it.uniroma3.siw.museo.controller;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Base64Utils;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import it.uniroma3.siw.museo.controller.validator.ArtistaValidator;
import it.uniroma3.siw.museo.controller.validator.CollezioneValidator;
import it.uniroma3.siw.museo.controller.validator.CredentialsValidator;
import it.uniroma3.siw.museo.controller.validator.CuratoreValidator;
import it.uniroma3.siw.museo.controller.validator.MuseoValidator;
import it.uniroma3.siw.museo.controller.validator.OperaValidator;
import it.uniroma3.siw.museo.controller.validator.UtenteValidator;
import it.uniroma3.siw.museo.model.Artista;
import it.uniroma3.siw.museo.model.Collezione;
import it.uniroma3.siw.museo.model.Credentials;
import it.uniroma3.siw.museo.model.Curatore;
import it.uniroma3.siw.museo.model.Museo;
import it.uniroma3.siw.museo.model.Opera;
import it.uniroma3.siw.museo.model.Utente;
import it.uniroma3.siw.museo.service.ArtistaService;
import it.uniroma3.siw.museo.service.CollezioneService;
import it.uniroma3.siw.museo.service.CredentialsService;
import it.uniroma3.siw.museo.service.CuratoreService;
import it.uniroma3.siw.museo.service.MuseoService;
import it.uniroma3.siw.museo.service.OperaService;
import it.uniroma3.siw.museo.service.UtenteService;


@Controller
public class AuthenticationController {
	private static final String UPLOAD_DIR = "\\images\\images_opere\\";

	@Autowired
	private CredentialsService credentialsService;

	@Autowired
	private UtenteValidator userValidator;

	@Autowired
	private CuratoreService curatoreService;

	@Autowired
	private CuratoreValidator curatoreValidator;

	@Autowired
	private MuseoService museoService;

	@Autowired
	private MuseoValidator museoValidator;

	@Autowired
	private CollezioneValidator collezioneValidator;

	@Autowired
	private ArtistaValidator artistaValidator;

	@Autowired
	private OperaValidator operaValidator;

	@Autowired
	private CredentialsValidator credentialsValidator;

	@Autowired
	private ArtistaService artistaService;

	@Autowired
	private OperaService operaService;

	@Autowired
	private CollezioneService collezioneService;

	@Autowired
	private UtenteService utenteService;

	@Autowired
	private CredentialsService credenzialiService;

	/*Metodi get autenticazione
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/registerUser", method = RequestMethod.GET) 
	public String showRegisterForm (Model model) {
		model.addAttribute("utente", new Utente());
		model.addAttribute("credentials", new Credentials());
		return "registerUser";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET) 
	public String showLoginForm (Model model) {
		return "login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET) 
	public String logout(Model model) {
		return "index"; 
	}

	@RequestMapping(value = "/default", method = RequestMethod.GET)
	public String defaultAfterLogin(Model model) {

		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)) {
			return "supervisor/home";
		}
		if (credentials.getRole().equals(Credentials.ADMIN_ROLE)) {
			return "admin/home";
		}
		if (credentials.getRole().equals(Credentials.DEFAULT_ROLE)) {
			return "user/home";
		}
		return "home";
	}

	@RequestMapping(value = { "/registerUser" }, method = RequestMethod.POST)
	public String registerUser(@ModelAttribute("utente") Utente user,
			BindingResult userBindingResult,
			@ModelAttribute("credentials") Credentials credentials,
			BindingResult credentialsBindingResult,
			Model model) {

		/* validate user and credentials fields*/
		//        this.userValidator.validate(user, userBindingResult);
		//        this.credentialsValidator.validate(credentials, credentialsBindingResult);

		/* if neither of them had invalid contents, store the User and the Credentials into the DB*/
		//        if(!userBindingResult.hasErrors() && ! credentialsBindingResult.hasErrors()) {
		//            // set the user and store the credentials;
		//            // this also stores the User, thanks to Cascade.ALL policy
		if(this.userValidator.validateCognome(user) && this.userValidator.validateNome(user) && 
				this.credentialsValidator.validateMessagePassword(credentials) && 
				this.credentialsValidator.validateMessageUsername(credentials)) {
			credentials.setUser(user);
			credentialsService.saveCredentials(credentials);
			return "registrationSuccessful";
		}	

		return "registerUser";
	}  



	/*Metodi get aggiungi
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/supervisor/aggiungi_info_museo", method = RequestMethod.GET) 
	public String aggiungiMuseo(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)) {
			model.addAttribute("aggiungi_info_museo", new Museo());
			return "supervisor/aggiungi_info_museo";
		}
		return "home";
	}

	@RequestMapping(value = "/supervisor/aggiungi_curatore", method = RequestMethod.GET) 
	public String aggiungiCuratore(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)) {
			model.addAttribute("aggiungi_curatore", new Curatore());
			return "supervisor/aggiungi_curatore";
		}
		return "home";
	}

	@RequestMapping(value = "/admin/aggiungi_artista", method = RequestMethod.GET) 
	public String aggiungiArtista(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (credentials.getRole().equals(Credentials.ADMIN_ROLE)|| (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) {
			model.addAttribute("aggiungi_artista", new Artista());
			return "admin/aggiungi_artista";
		}
		return "home";
	}

	@RequestMapping(value = "/admin/aggiungi_opera", method = RequestMethod.GET) 
	public String aggiungiOpera(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (credentials.getRole().equals(Credentials.ADMIN_ROLE)|| (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) {
			model.addAttribute("aggiungi_opera", new Opera());
			return "admin/aggiungi_opera";
		}
		return "home";
	}

	@RequestMapping(value = "/admin/aggiungi_collezione", method = RequestMethod.GET) 
	public String aggiungiCollezione(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if (credentials.getRole().equals(Credentials.ADMIN_ROLE)|| (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) {
			model.addAttribute("aggiungi_collezione", new Collezione());
			return "admin/aggiungi_collezione";
		}
		return "home";
	}



	/* Metodi post aggiungi
	 * 
	 * @param aggiungi 
	 * @param model
	 * @param bindingResult
	 * @return
	 */
	@RequestMapping(value = "/supervisor/aggiungi_info_museo", method = RequestMethod.POST)
	public String addMuseo(@ModelAttribute("aggiungi_info_museo") Museo aggiungi_info_museo, 
			Model model, BindingResult bindingResult) {
		if(!this.museoValidator.validation(aggiungi_info_museo))
			return "supervisor/aggiungi_info_museo";    	    	

		if(this.museoValidator.validaModifica(aggiungi_info_museo)) {
			this.museoService.aggiorna(aggiungi_info_museo); 
			model.addAttribute("visualizza_info_museo", this.museoService.tuttiIMuseo()); 
			return "supervisor/visualizza_info_museo";
		}

		this.museoValidator.validate(aggiungi_info_museo, bindingResult);
		if (!bindingResult.hasErrors()) {
			if(this.museoService.alreadyNotExists()) {
				this.museoService.inserisci(aggiungi_info_museo);     		    		
			}
			model.addAttribute("visualizza_info_museo", this.museoService.tuttiIMuseo()); 
			return "supervisor/visualizza_info_museo";
		}
		return "supervisor/aggiungi_info_museo";
	}

	@RequestMapping(value = "/supervisor/aggiungi_curatore", method = RequestMethod.POST)
	public String addCuratore(@ModelAttribute("aggiungi_curatore") Curatore aggiungi_curatore,
			@RequestParam("mydatetime") String dataN, 
			Model model, BindingResult bindingResult) {

		if(!this.curatoreValidator.validation(aggiungi_curatore))
			return "supervisor/aggiungi_curatore"; 
		

		if(!this.curatoreValidator.validaMatricola(aggiungi_curatore))
			return "supervisor/aggiungi_curatore";

		aggiungi_curatore.setDataDiNascita(dataN);
		aggiungi_curatore.setDataDiNascita(formatoDataVecchioStile(aggiungi_curatore.getDataDiNascita()));
		
		if(this.curatoreValidator.validaModifica(aggiungi_curatore)) {
			this.curatoreService.aggiorna(aggiungi_curatore); 
			model.addAttribute("visualizza_curatori", this.curatoreService.tuttiICuratori());
			return "supervisor/visualizza_curatori";
		}

		this.curatoreValidator.validate(aggiungi_curatore, bindingResult);
		if (!bindingResult.hasErrors()) {
			this.curatoreService.inserisci(aggiungi_curatore);
			model.addAttribute("visualizza_curatori", this.curatoreService.tuttiICuratori());
			return "supervisor/visualizza_curatori";
		}
		return "supervisor/aggiungi_curatore";
	}

	@RequestMapping(value = "/admin/aggiungi_artista", method = RequestMethod.POST)
	public String addArtista(@ModelAttribute("aggiungi_artista") Artista aggiungi_artista,
			@RequestParam("mydatetime1") String dataN, @RequestParam("mydatetime2") String dataM,
			Model model, BindingResult bindingResult) {
		
		

		if(!this.artistaValidator.validation(aggiungi_artista))
			return "admin/aggiungi_artista";    	    	

		
		aggiungi_artista.setDataDiNascita(dataN);
		aggiungi_artista.setDataDiNascita(formatoDataVecchioStile(aggiungi_artista.getDataDiNascita()));
		aggiungi_artista.setDataDiMorte(dataM);
		aggiungi_artista.setDataDiMorte(formatoDataVecchioStile(aggiungi_artista.getDataDiMorte()));
		
		
		if(this.artistaValidator.validaModifica(aggiungi_artista)) {			
			this.artistaService.aggiorna(aggiungi_artista); 
			model.addAttribute("visualizza_artisti", this.artistaService.tuttiGliArtisti());
			return "admin/visualizza_artisti";
		}

		this.artistaValidator.validate(aggiungi_artista, bindingResult);    	
		if (!bindingResult.hasErrors()) {        		
			this.artistaService.inserisci(aggiungi_artista);
			model.addAttribute("visualizza_artisti", this.artistaService.tuttiGliArtisti());
			return "admin/visualizza_artisti";
		}

		return "admin/aggiungi_artista";
	}


	@RequestMapping(value = "/admin/aggiungi_opera", method = RequestMethod.POST)
	public String addOpera(@ModelAttribute("aggiungi_opera") Opera aggiungi_opera,
			@RequestParam("file") MultipartFile file, RedirectAttributes attributes,
			Model model, BindingResult bindingResult) throws IOException {

		if(!this.operaValidator.validation(aggiungi_opera)) {
			return "admin/aggiungi_opera";  
		}

		@SuppressWarnings("unused")
		String fileName = null;
		if(this.operaValidator.validaModifica(aggiungi_opera)) {
			fileName = StringUtils.cleanPath(file.getOriginalFilename());
			this.uploadDataBase(aggiungi_opera, file);
			this.operaService.aggiorna(aggiungi_opera);  		    
			model.addAttribute("visualizza_opere", this.operaService.tutteLeOpere());
			return "admin/visualizza_opere";
		}    

		this.operaValidator.validate(aggiungi_opera, bindingResult);
		if (!bindingResult.hasErrors()) {
			fileName = StringUtils.cleanPath(file.getOriginalFilename());

			this.uploadDataBase(aggiungi_opera, file);
			this.operaService.inserisci(aggiungi_opera);        	
			model.addAttribute("visualizza_opere", this.operaService.tutteLeOpere());

			return "admin/visualizza_opere";
		}
		return "admin/aggiungi_opera";
	}

	@RequestMapping(value = "/admin/aggiungi_collezione", method = RequestMethod.POST)
	public String addCollezione(@ModelAttribute("aggiungi_collezione") Collezione aggiungi_collezione, 
			@RequestParam("mydatetime") String dataN, Model model, BindingResult bindingResult) {

		if(!this.collezioneValidator.validation(aggiungi_collezione))
			return "admin/aggiungi_collezione";  
		
		aggiungi_collezione.setDatacreazione(dataN);
		aggiungi_collezione.setDatacreazione(formatoDataVecchioStile(aggiungi_collezione.getDatacreazione()));

		if(this.collezioneValidator.validaModifica(aggiungi_collezione)) {
			this.collezioneService.aggiorna(aggiungi_collezione); 
			model.addAttribute("visualizza_collezioni", this.collezioneService.tutteLeCollezioni());
			return "admin/visualizza_collezioni";
		}

		this.collezioneValidator.validate(aggiungi_collezione, bindingResult);
		if (!bindingResult.hasErrors()) {
			this.collezioneService.inserisci(aggiungi_collezione);
			model.addAttribute("visualizza_collezioni", this.collezioneService.tutteLeCollezioni());
			return "admin/visualizza_collezioni";
		}
		return "admin/aggiungi_collezione";
	}     



	/*Metpdp post associa indici
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/admin/visualizza_lista_artisti/{id}", method = RequestMethod.POST)
	public String addOpera(@PathVariable("id") Long id, @RequestParam(name = "sub", required = false) Long id_opera, Model model) {

		if(id_opera>0){
			if(this.operaValidator.validaArtista(id)) { 
				this.operaService.aggiornaArtista(id_opera, id);    			
				model.addAttribute("visualizza_opere_ass", this.operaService.selezionaOpereNonAssociate());
				return "admin/visualizza_opere_ass";
			}
		}

		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_lista_opere/{id}", method = RequestMethod.POST)
	public String addArtista(@PathVariable("id") Long id, @RequestParam(name = "sub", required = false) Long id_artista, Model model) {

		if(id_artista>0){
			if(this.operaValidator.validaArtista(id_artista)) { 
				this.operaService.aggiornaArtista(id, id_artista);
				model.addAttribute("associa_artista", id_artista);
				model.addAttribute("visualizza_lista_opere", this.operaService.selezionaOpereNonAssociate());
				return "admin/visualizza_lista_opere"; 
			}
		}

		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_lista_opere_collezioni/{id}", method = RequestMethod.POST)
	public String addCollezioni(@PathVariable("id") Long id, @RequestParam(name = "sub", required = false) Long id_collezione, Model model) {

		if(id_collezione>0){
			if(this.operaValidator.validaCollezione(id_collezione)) { 
				this.operaService.aggiornaCollezione(id, id_collezione);
				model.addAttribute("associa_collezioni", id_collezione);
				model.addAttribute("visualizza_lista_opere_collezioni", this.operaService.selezionaOpereCollezioniNonAssociate());
				return "admin/visualizza_lista_opere_collezioni"; 
			}
		}

		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_lista_collezioni/{id}", method = RequestMethod.POST)
	public String addCuratore(@PathVariable("id") Long id, @RequestParam(name = "sub", required = false) Long id_curatore, Model model) {

		if(id_curatore>0){
			if(this.collezioneValidator.validaCuratore(id_curatore)) { 
				this.collezioneService.aggiornaCollezione(id, id_curatore);
				model.addAttribute("associa_curatore", id_curatore);
				model.addAttribute("visualizza_lista_collezioni", this.collezioneService.selezionaCollezioniNonAssociateCuratore());
				return "admin/visualizza_lista_collezioni"; 
			}
		}

		return "home";
	}



	/*Metodi post modifica  
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/modifica_museo/{id}", method = RequestMethod.POST)
	public String modificaMuseo(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))  {	
			if(this.museoService.alreadyExists(id)) {
				model.addAttribute("aggiungi_info_museo", this.museoService.museoPerId(id));        				    		
			}
			return "supervisor/aggiungi_info_museo";
		}
		return "home";
	}

	@RequestMapping(value = "/modifica_curatore/{id}", method = RequestMethod.POST)
	public String modificaCuratore(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))  {	
			if(this.curatoreService.alreadyExists(id)) {
				Curatore c =this.curatoreService.curatorePerId(id);
				c.setDataDiNascita(riformatoDataVecchioStile(c.getDataDiNascita()));
				model.addAttribute("aggiungi_curatore", c);        				    		
			}
			return "supervisor/aggiungi_curatore";
		}
		return "home";
	}

	@RequestMapping(value = "/modifica_artista/{id}", method = RequestMethod.POST)
	public String modificaArtista(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {	
			if(this.artistaService.alreadyExists(id)) {
				Artista a = this.artistaService.artistiPerId(id);
				a.setDataDiNascita(riformatoDataVecchioStile(a.getDataDiNascita()));
				a.setDataDiMorte(riformatoDataVecchioStile(a.getDataDiMorte()));					
				model.addAttribute("aggiungi_artista", a);
			}
			return "admin/aggiungi_artista";
		}
		return "home";
	}

	@RequestMapping(value = "/modifica_opera/{id}", method = RequestMethod.POST)
	public String modificaOpera(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {	
			if(this.operaService.alreadyExists(id)) {
				model.addAttribute("aggiungi_opera", this.operaService.operaPerId(id));
			}
			return "admin/aggiungi_opera";
		}
		return "home";
	}

	@RequestMapping(value = "/modifica_collezione/{id}", method = RequestMethod.POST)
	public String modificaCollezione(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {	
			if(this.collezioneService.alreadyExists(id)) {
				Collezione c = this.collezioneService.collezionePerId(id);
				c.setDatacreazione(riformatoDataVecchioStile(c.getDatacreazione()));
				model.addAttribute("aggiungi_collezione", c );
			}
			return "admin/aggiungi_collezione";
		}
		return "home";
	}

	/**/
	@RequestMapping(value = "/supervisor/modifica_credenziali", method = RequestMethod.POST)
	public String modificaCredenziali( @ModelAttribute("modifica_credenziali") Credentials modifica_credenziali, 
			Model model, @RequestParam(name = "sub", required = false) Long id_utente,
			@RequestParam(name = "username", required = false) String username, 
			@RequestParam(name = "password", required = false) String password, 
			@RequestParam(name = "ruolo", required = false) String ruolo, 
			@RequestParam(name = "ruolo_cambiato", required = false) String ruolo_cambiato) {

		if(!this.credentialsValidator.validateMessageRuoloModifica(ruolo_cambiato) 
				&& !this.credentialsValidator.validateMessagePasswordModifica(password) 
				&& !this.credentialsValidator.validateMessageUsernameModifica(username) ) {
			this.credenzialiService.aggiornaRuoloUtente(id_utente, ruolo_cambiato); 
			model.addAttribute("visualizza_utenti", this.utenteService.tuttiGliUtenti());
			return "supervisor/visualizza_utenti";
		}    	

		return "supervisor/modifica_credenziali";
	}

	/*Metodi post elimina
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/elimina_museo/{id}", method = RequestMethod.POST)
	public String removeMuseo(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))  {
			if(museoService.alreadyExists(id)) {
				this.museoService.dissociaCuratori(id);
				this.museoService.eliminaMuseoId(id);
			}
			model.addAttribute("visualizza_info_museo", this.museoService.tuttiIMuseo());
			return "supervisor/visualizza_info_museo";
		}
		return "home";
	}

	@RequestMapping(value = "/elimina_curatore/{id}", method = RequestMethod.POST)
	public String removeCuratore(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))  {
			if(curatoreService.alreadyExists(id)) {
				this.curatoreService.dissociaMuseo(id);
				this.curatoreService.dissociaCollezioni(id);
				this.curatoreService.eliminaCuratoreId(id);
			}	
			model.addAttribute("visualizza_curatori", this.curatoreService.tuttiICuratori());
			return "supervisor/visualizza_curatori";
		}
		return "home";
	}

	@RequestMapping(value = "/elimina_artista/{id}", method = RequestMethod.POST)
	public String removeArtista(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {	
			if(artistaService.alreadyExists(id)) {
				this.operaService.dissociaOpere(id);
				this.artistaService.eliminaArtistaId(id);
			}
			model.addAttribute("visualizza_artisti", this.artistaService.tuttiGliArtisti());
			return "admin/visualizza_artisti";
		}
		return "home";
	}

	@RequestMapping(value = "/elimina_opera/{id}", method = RequestMethod.POST)
	public String removeOpera(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {	
			if(operaService.alreadyExists(id)) {
				this.operaService.dissociaArtista(id);
				this.operaService.eliminaOperaId(id);
			}
			model.addAttribute("visualizza_opere", this.operaService.tutteLeOpere());
			return "admin/visualizza_opere";
		}
		return "home";
	}

	@RequestMapping(value = "/elimina_collezione/{id}", method = RequestMethod.POST)
	public String removeCollezione(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {
			if(collezioneService.alreadyExists(id)) {
				this.collezioneService.dissociaCuratore(id);
				this.collezioneService.eliminaCollezioneId(id);
			}
			model.addAttribute("visualizza_collezioni", this.collezioneService.tutteLeCollezioni());
			return "admin/visualizza_collezioni";
		}
		return "home";
	}



	/*Metodi get associa  
	 * 
	 * @param id
	 * @param model
	 * @return
	 */    
	@RequestMapping(value = "/admin/visualizza_lista_artisti/{id}", method = RequestMethod.GET)
	public String associaOpera(@PathVariable("id") Long id, Model model ) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {			
			model.addAttribute("associa_opera", id);
			model.addAttribute("visualizza_lista_artisti", this.artistaService.tuttiGliArtisti());
			return "admin/visualizza_lista_artisti";     		           
		}
		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_lista_opere/{id}", method = RequestMethod.GET)
	public String associaArtista(@PathVariable("id") Long id, Model model ) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {
			model.addAttribute("associa_artista", id);
			model.addAttribute("visualizza_lista_opere", this.operaService.selezionaOpereNonAssociate());
			return "admin/visualizza_lista_opere";     		           
		}
		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_lista_opere_collezioni/{id}", method = RequestMethod.GET)
	public String associaCollezione(@PathVariable("id") Long id, Model model ) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {
			model.addAttribute("associa_collezioni", id);
			model.addAttribute("visualizza_lista_opere_collezioni", this.operaService.selezionaOpereCollezioniNonAssociate());
			return "admin/visualizza_lista_opere_collezioni";     		           
		}
		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_lista_collezioni/{id}", method = RequestMethod.GET)
	public String associaCuratore(@PathVariable("id") Long id, Model model ) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {
			model.addAttribute("associa_curatore", id);
			model.addAttribute("visualizza_lista_collezioni", this.collezioneService.selezionaCollezioniNonAssociateCuratore());
			return "admin/visualizza_lista_collezioni";     		           
		}
		return "home";
	}



	/*Metodi post dissocia
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/dissocia_opera/{id}", method = RequestMethod.POST)
	public String dissociaOpera(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {	
			if(operaService.alreadyExists(id)) {
				this.operaService.dissociaArtista(id);
			}
			model.addAttribute("visualizza_opere", this.operaService.tutteLeOpere());
			return "admin/visualizza_opere";
		}
		return "home";
	}

	@RequestMapping(value = "/dissocia_artista/{id}", method = RequestMethod.POST)
	public String dissociaArtista(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ((credentials.getRole().equals(Credentials.ADMIN_ROLE)) || ( credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)))  {	
			if(operaService.alreadyExists(id)) {
				this.operaService.dissociaOpere(id);
			}
			model.addAttribute("visualizza_artisti", this.artistaService.tuttiGliArtisti());
			return "admin/visualizza_artisti";
		}
		return "home";
	}



	/*Metodi get visualizza tutti
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/admin/visualizza_artisti", method = RequestMethod.GET) 
	public String visualizzaAdminArtisti(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)) ) {
			model.addAttribute("visualizza_artisti", this.artistaService.tuttiGliArtisti());
			return "admin/visualizza_artisti";
		}
		return "home";
	}

	@RequestMapping(value = "/visualizza_artisti", method = RequestMethod.GET) 
	public String visualizzaArtisti(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.DEFAULT_ROLE)|| (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) ) {
			model.addAttribute("visualizza_artisti", this.artistaService.tuttiGliArtisti());
			return "user/visualizza_artisti";
		}
		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_opere", method = RequestMethod.GET) 
	public String visualizzaAdminOpere(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)) ) {
			model.addAttribute("visualizza_opere", this.operaService.tutteLeOpere());
			return "admin/visualizza_opere";
		}
		return "home";
	}   

	@RequestMapping(value = "/visualizza_opere", method = RequestMethod.GET) 
	public String visualizzaOpere(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.DEFAULT_ROLE)|| (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) ) {
			model.addAttribute("visualizza_opere", this.operaService.tutteLeOpere());
			return "user/visualizza_opere";
		}
		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_collezioni", method = RequestMethod.GET) 
	public String visualizzaAdminCollezioni(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)) ) {
			model.addAttribute("visualizza_collezioni", this.collezioneService.tutteLeCollezioni());
			return "admin/visualizza_collezioni";
		}
		return "home";
	}

	@RequestMapping(value = "/visualizza_collezioni", method = RequestMethod.GET) 
	public String visualizzaCollezioni(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.DEFAULT_ROLE)|| (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) ) {
			model.addAttribute("visualizza_collezioni", this.collezioneService.tutteLeCollezioni());
			return "user/visualizza_collezioni";
		}
		return "home";
	}

	@RequestMapping(value = "/visualizza_curatori", method = RequestMethod.GET) 
	public String visualizzaCuratori(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))    {
			model.addAttribute("visualizza_curatori", this.curatoreService.tuttiICuratori());
			return "supervisor/visualizza_curatori";
		}
		return "home";
	}

	@RequestMapping(value = "/visualizza_info_museo", method = RequestMethod.GET) 
	public String visualizzaInfoMuseo(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))    {
			model.addAttribute("visualizza_info_museo", this.museoService.tuttiIMuseo());
			return "supervisor/visualizza_info_museo";
		}
		return "home";
	}

	/**/
	@RequestMapping(value = "/visualizza_utenti", method = RequestMethod.GET) 
	public String visualizzaTuttiGliUtenti(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))    {
			model.addAttribute("visualizza_utenti", this.utenteService.ritornaUtenzaRuoliEsclusoSuper());
			return "supervisor/visualizza_utenti";
		}
		return "home";
	}

	/*Metodi get visualizza per associazioni
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/admin/visualizza_opere_ass", method = RequestMethod.GET) 
	public String visualizzaOpereAssociazioneArtista(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) {
			model.addAttribute("visualizza_opere_ass",  this.operaService.selezionaOpereNonAssociate());
			return "admin/visualizza_opere_ass";
		}
		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_artisti_ass", method = RequestMethod.GET) 
	public String visualizzaArtistaAssociazioneOpere(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) {
			model.addAttribute("visualizza_artisti_ass",  this.artistaService.tuttiGliArtisti());
			return "admin/visualizza_artisti_ass";
		}
		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_collezioni_ass", method = RequestMethod.GET) 
	public String visualizzaOpereAssociazioneCollezioni(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) {
			model.addAttribute("visualizza_collezioni_ass",  this.collezioneService.tutteLeCollezioni());
			return "admin/visualizza_collezioni_ass";
		}
		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_curatori_ass", method = RequestMethod.GET) 
	public String visualizzaCuratoriAssociazioneCollezioni(Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) {
			model.addAttribute("visualizza_curatori_ass",  this.curatoreService.tuttiICuratori());
			return "admin/visualizza_curatori_ass";
		}
		return "home";
	}



	/*Metodo get visualizza per indice
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/visualizza_artista/{id}", method = RequestMethod.GET) 
	public String visualizzaArtista(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.DEFAULT_ROLE)|| (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) ) {
			model.addAttribute("visualizza_artista", this.artistaService.artistiPerId(id));
			model.addAttribute("opere", this.operaService.operePerArtista(id));
			
			
			return "user/visualizza_artista";
		}
		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_artista/{id}", method = RequestMethod.GET) 
	public String visualizzaAdminArtista(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)) ) {
			model.addAttribute("visualizza_artista", this.artistaService.artistiPerId(id)); 
			model.addAttribute("opere",  this.operaService.operePerArtista(id));

			return "admin/visualizza_artista";
		}
		return "home";
	}

	@RequestMapping(value = "/visualizza_opera/{id}", method = RequestMethod.GET) 
	public String visualizzaOpera(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.DEFAULT_ROLE)|| (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) ) {
			model.addAttribute("visualizza_opera", this.operaService.operaPerId(id));
			model.addAttribute("image", Base64Utils.encodeToString(this.ritornaImmagine(id)));
			return "user/visualizza_opera";
		}
		return "home";
	}

	/****************/
	
	@RequestMapping(value = "/admin/visualizza_opera/{id}", method = RequestMethod.GET) 
	public String visualizzaAdminOpera(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)) ) {
			model.addAttribute("visualizza_opera", this.operaService.operaPerId(id));    		
			model.addAttribute("image", Base64Utils.encodeToString(this.ritornaImmagine(id)));
			return "admin/visualizza_opera";
		}
		return "home";
	}
	
	
	@RequestMapping(value = "/user/opera/{id}", method = RequestMethod.GET) 
	public String visualizzaPopUpOpera(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.DEFAULT_ROLE) || (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) ) {
			 		
			model.addAttribute("image", Base64Utils.encodeToString(this.ritornaImmagine(id)));
			return "user/opera";
		}
		return "home";
	}

	@RequestMapping(value = "/visualizza_collezione/{id}", method = RequestMethod.GET) 
	public String visualizzaCollezione(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.DEFAULT_ROLE)|| (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))) ) {
			model.addAttribute("visualizza_collezione", this.collezioneService.collezionePerId(id));
			model.addAttribute("opere", operaService.operePerCollezione(id));
			return "user/visualizza_collezione";
		}
		return "home";
	}

	@RequestMapping(value = "/admin/visualizza_collezione/{id}", method = RequestMethod.GET) 
	public String visualizzaAdminCollezione(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if ( (credentials.getRole().equals(Credentials.ADMIN_ROLE)) || (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE)) ) {
			model.addAttribute("visualizza_collezione", this.collezioneService.collezionePerId(id));
			model.addAttribute("opere", operaService.operePerCollezione(id));
			return "admin/visualizza_collezione";
		}
		return "home";
	}

	@RequestMapping(value = "/visualizza_curatore/{id}", method = RequestMethod.GET) 
	public String visualizzaCuratore(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))    {
			model.addAttribute("visualizza_curatore", this.curatoreService.curatorePerId(id));
			model.addAttribute("collezioni", this.collezioneService.selezionaCollezioniAssociateCuratore(id));
			return "supervisor/visualizza_curatore";
		}
		return "home";
	}

	/**/
	@RequestMapping(value = "supervisor/visualizza_credenziali/{id}", method = RequestMethod.GET) 
	public String visualizzaCredenziali(@PathVariable("id") Long id, Model model) {
		UserDetails userDetails = (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Credentials credentials = credentialsService.getCredentials(userDetails.getUsername());
		if  (credentials.getRole().equals(Credentials.SUPERVISOR_ROLE))    {
			model.addAttribute("associa_credenziali", id);


			if(this.credenzialiService.ritornaCredenzialiUtente(id)!=null)
				credentials = this.credentialsService.getCredentials(this.credenzialiService.ritornaCredenzialiUtente(id));
			model.addAttribute("visualizza_credenziali_username", credentials.getUsername());
			model.addAttribute("visualizza_credenziali_password", credentials.getPassword());
			model.addAttribute("visualizza_credenziali_ruolo", credentials.getRole());
			model.addAttribute("visualizza_credenziali_id", credentials.getId());
			return "supervisor/modifica_credenziali";

		}
		return "home";
	}
	
	 private boolean uploadDataBase(Opera aggiungi_opera, MultipartFile file) throws IOException {

			try {
					byte[] imgByte = new byte[file.getBytes().length];
					int j = 0;
					for(byte b : file.getBytes()) {
						imgByte[j++]=b;
					}
					aggiungi_opera.setFoto(imgByte);
				
					return true;
				
			}catch (Exception e) {
				return false;
			}    	    	
		}

	 private  byte[] ritornaImmagine(Long id) {
			Opera o = this.operaService.operaPerId(id);
			byte[] b = (byte[]) ArrayUtils.toPrimitive(o.getFoto());
			return b;

		}
		
	 @SuppressWarnings("unused")
	private  List<Opera> ritornaListaImmagini(List<Opera> opere){
			 
			for(Opera o : opere)
				o.setPath( Base64Utils.encodeToString(ritornaImmagine(o.getId())));	
			return  opere;
		}


		@SuppressWarnings("unused")
		private   String uploadFile(String fileName, Opera aggiungi_opera, MultipartFile file) {
			String path_opera=null;
			try 
			{
				for (Museo l : this.museoService.tuttiIMuseo()) {
					path_opera = l.getPathopere();
				}
				if(path_opera!=null) {
					java.nio.file.Path path = Paths.get(path_opera + String.valueOf(aggiungi_opera.getId()) + fileName);
					Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
					aggiungi_opera.setPath(UPLOAD_DIR + fileName);
					path_opera=UPLOAD_DIR + String.valueOf(aggiungi_opera.getId()) + fileName;
				}		
			}
			catch (IOException e) {

			}
			return path_opera;
		}
		
		private String formatoDataVecchioStile(String dataDaFormattare) {
			if(dataDaFormattare!=null) {
				/*yyyy-mm-dd --> 0123-56-89*/ 
				String text =  dataDaFormattare.substring(8,10)+ "-" + dataDaFormattare.substring(5,7) + "-"+ dataDaFormattare.substring(0,4);
				return text;	    	
			}
			else {
				return dataDaFormattare;
			}
		}

		private String riformatoDataVecchioStile(String dataDaFormattare) {
			if(dataDaFormattare!=null) {
				/*dd-mm-yyyy --> 01-34-6789*/
				
				String text =  dataDaFormattare.substring(6,10)+ "-" + dataDaFormattare.substring(3,5) + "-"+ dataDaFormattare.substring(0,2);
				return text;	    	
			}
			else {
				return dataDaFormattare;
			}
		}
		
}
