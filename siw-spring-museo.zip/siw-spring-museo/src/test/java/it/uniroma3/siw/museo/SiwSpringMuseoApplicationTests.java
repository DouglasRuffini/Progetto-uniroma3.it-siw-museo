package it.uniroma3.siw.museo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiwSpringMuseoApplicationTests {

	@Test
	void contextLoads() {
	}

}
